package sefA1;

public class Staff {

	private String username;
	private String password;

	public void Staff(String username, String password)
	{
		this.username = username;
		this.password = password;
	}
}
