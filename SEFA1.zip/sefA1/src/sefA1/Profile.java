package sefA1;

public class Profile {

	
	private String name;
	private String dob;
	private String phone;
	private String email;

	public void Profile(String name, String dob, String phone, String email)
	{
		this.name=name;
		this.dob=dob;
		this.phone=phone;
		this.email=email;
	}
	
	public void updateProfile()
	{
	//to-do	
	}
	
	public void updateResume()
	{
	//to-do	
	}
	
}
