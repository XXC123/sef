package sefA1;

public class RosterEvent {

	
	private String name;
	private String start;
	private String end;
	private String payRate;

	public void RosterEvent(String name, String start, String end, String payRate)
	{
		this.name=name;
		this.start=start;
		this.end=end;
		this.payRate=payRate;
	}
	
	public void createEvent()
	{
	//to-do	
	}
	
	public void deleteEvent()
	{
	//to-do	
	}
	
	public void requestStaff()
	{
	//to-do	
	}
}
