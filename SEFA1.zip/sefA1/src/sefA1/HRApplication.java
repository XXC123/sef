package sefA1;

public class HRApplication {

	
	
	public void login()
	{
	//to-do	
	}
	
	
	public void message()
	{
	//to-do	
	}
	public void viewAnnouncements()
	{
	//to-do	
	}
	public void checkPaytate()
	{
	//to-do	
	}
	public void seeRoster()
	{
	//to-do	
	}
	public void applyPosition()
	{
	//to-do	
	}
	public void viewStaff()
	{
	//to-do	
	}
	public void viewCourseStaffRequest()
	{
	//to-do	
	}
	public void setRoster()
	{
	//to-do	
	}
	public void allocateStaff()
	{
	//to-do	
	}
	public void gatherPayroll()
	{
	//to-do	
	}
	public void approveStaffPay()
	{
	//to-do	
	}
	public void seeCourseBudget()
	{
	//to-do	
	}
	public void createCourseBudget()
	{
	//to-do	
	}
	public void createCourseEvent()
	{
	//to-do	
	}public void StaffForEvent()
	{
	//to-do	
	}public void Announcement()
	{
	//to-do	
	}
	public void viewProfile()
	{
	//to-do	
	}
	}

