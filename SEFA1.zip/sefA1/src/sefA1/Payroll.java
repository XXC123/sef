package sefA1;

public class Payroll {

	
	public void confirmWeeklyPay()
	{
	//to-do	
	}
}
