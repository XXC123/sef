package sefA1;

public class Roster {

	
	private int day;
	private int month;
	private int year;

	public void Roster(int day, int month, int year)
	{
		this.day=day;
		this.month=month;
		this.year=year;
	}
	
	public void rosterEvent()
	{
	//to-do	
	}
	
	public void viewEvent()
	{
	//to-do	
	}
	
	public void applyForEvent()
	{
	//to-do	
	}
}
