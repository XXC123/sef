package sefA1;

public class Approval {

	
	public void approveRequest()
	{
	//to-do	
	}
	
	public void denyRequest()
	{
	//to-do	
	}
	
	public void editRequest()
	{
	//to-do	
	}
}
