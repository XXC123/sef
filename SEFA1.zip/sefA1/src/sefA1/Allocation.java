package sefA1;

public class Allocation {

	
	public void addStaffToEvent()
	{
	//to-do	
	}
	public void removeStaffToEvent()
	{
	//to-do	
	}
}
