package sefA1;

public class announcement {

	
	private String announcement;

	public void announcement(String announcement)
	{
		this.announcement=announcement;
	}
	
	
public void createAnnouncement()
	{
	//to-do	
	}
	

public void DeleteAnnouncement()
{
//to-do	
}
}