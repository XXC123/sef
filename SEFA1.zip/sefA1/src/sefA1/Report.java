package sefA1;

public class Report {

	
	public void generateReport()
	{
	//to-do	
	}
}
